import pandas as pd
from itertools import islice
import matplotlib.pyplot as plt
from statistics import mean

gdpData = pd.read_csv(
    'API_NY.GDP.MKTP.CN_DS2_en_csv_v2_4150804/API_NY.GDP.MKTP.CN_DS2_en_csv_v2_4150804.csv', skiprows=3)
countryStatistics = pd.read_csv(
    'API_NY.GDP.MKTP.CN_DS2_en_csv_v2_4150804/Metadata_Country_API_NY.GDP.MKTP.CN_DS2_en_csv_v2_4150804.csv')

# oczyszczamy dane z rzeczy ktore sie nam nie przydadza
# 2021 - brak informacji
gdpData.drop(['Country Code', 'Indicator Name', 'Indicator Code', '2021', 'Unnamed: 66'], inplace=True, axis=1)
countryStatistics.drop(['SpecialNotes', 'Unnamed: 5'], inplace=True, axis=1)

# zamieniamy NaN na 0
gdpData = gdpData.fillna(0)
countryStatistics = countryStatistics.fillna('None')

# punkt 1
last5Years = gdpData.iloc[:, -5:]

difference = []

# pierwsza wersja, ignorujemy - w kolumnie 2016 lub 2021
for index, row in last5Years.iterrows():
    if row[0] == 0 or row[4] == 0:
        difference.append(0)
        continue
    difference.append(row[4] - row[0])

# tu musi byc posortowany slownik
krajPlusWzrost = {}
for i in range(len(difference)):
    krajPlusWzrost[gdpData.iloc[i][0]] = difference[i]

krajPlusWzrost = dict(sorted(krajPlusWzrost.items(), key=lambda item: item[1], reverse=True))

namesOfCOuntries = list(islice(krajPlusWzrost, 10))
valuesOfGdb = list(islice(krajPlusWzrost.values(), 10))

y_pos = range(len(namesOfCOuntries))
plt.barh(namesOfCOuntries, valuesOfGdb, color="lightpink")
plt.tight_layout()
plt.subplots_adjust(top=0.9)
plt.title('Państwa z najwyższym wzrostem gospodarczym')
plt.show()

kraje = []
for kraj in countryStatistics["TableName"]:
    kraje.append(kraj)

# uwaga, w regionach None jako niezidentyfikowany region
regiony = []
for region in countryStatistics["Region"]:
    regiony.append(region)

krajPlusRegion = dict(zip(kraje, regiony))

counter = 0

krajeEuropyIAzjiCentralnej = []
wzroscik = []

for kraj, wzrost in krajPlusWzrost.items():
    if kraj == "Poland":
        print(f"Polska jest na {counter} miejscu wsrod krajow europejskich,"
              f" ze wzrostem gospodarczym: {wzrost} na przelomie 5 lat\n\n")
        krajeEuropyIAzjiCentralnej.append(kraj)
        wzroscik.append(wzrost)
        break

    if krajPlusRegion[kraj] == "Europe & Central Asia":
        krajeEuropyIAzjiCentralnej.append(kraj)
        wzroscik.append(wzrost)
        counter += 1

plt.barh(krajeEuropyIAzjiCentralnej[1:15], wzroscik[1:15], color="lightpink")
plt.tight_layout()
plt.subplots_adjust(top=0.9, right=0.8)
plt.title('Wzrost gospodarczy Polski na tle innych krajów Europy i Azji Centralnej')
plt.show()

krajePodzialNaRegiony = {}
for kraj, region in krajPlusRegion.items():
    if not region in krajePodzialNaRegiony.keys():
        krajePodzialNaRegiony[region] = [kraj]
    else:
        krajePodzialNaRegiony[region].append(kraj)

developmentInidcators = pd.read_csv(
    'API_NY.GDP.MKTP.CN_DS2_en_csv_v2_4150804/additional/Data_Extract_From_World_Development_Indicators/86fe5521-d4e5-4c79-9213-ed3146a0c31b_Data.csv')

krajeDI = []
for kraj in developmentInidcators["Country Name"]:
    krajeDI.append(kraj)

indyktory = []
for indykator in developmentInidcators["2020 [YR2020]"]:
    indyktory.append(indykator)

krajeDI = dict(zip(krajeDI, indyktory))

DIpodzialNaRegiony = {k: [] for k in krajePodzialNaRegiony.keys() if k != "None"}

for kraj, indykator in krajeDI.items():
    if indykator == "..":
        continue
    for region, kraje in krajePodzialNaRegiony.items():
        if kraj in kraje:
            DIpodzialNaRegiony[region].append(float(indykator))
            break

# w DIpodzialNaRegiony mamy indykatory dla kazdego regionu
# mozna podejzec, ale dla wizualizacji za duzo - wezmiemy srednia
namesOfRegions = []
meansOfIndicators = []
for region, indicators in DIpodzialNaRegiony.items():
    namesOfRegions.append(region)
    meansOfIndicators.append(mean(indicators))


y_pos = range(len(namesOfRegions))
plt.barh(namesOfRegions, meansOfIndicators, color="lightpink")
plt.title('Średnie DI na region')
plt.tight_layout()
plt.show()
